//
//  SongsDataResponseModel.swift
//  MusicApp
//
//  Created by Ahmad Qureshi on 26/09/23.
//

import Foundation
struct DataResponseModel: Codable {
    let data: [SongDataModel]
}

